<?php
// الاتصال بقاعدة البيانات
include 'db.php';
session_start(); // بدء الجلسة

// جلب المنتجات من قاعدة البيانات
$sql = "SELECT * FROM cat_products";
$result = $conn->query($sql);

$products = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
}

// حفظ الطلبات في جدول orders
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cartData'])) {
    $cartData = json_decode($_POST['cartData'], true);
    $userName = isset($_SESSION['user_name']) ? $_SESSION['user_name'] : 'Guest'; // جلب اسم المستخدم من الجلسة

    if (!empty($cartData)) {
        foreach ($cartData as $item) {
            $productId = intval($item['id']);
            $name = $item['name'];
            $quantity = intval($item['quantity']);
            $price = floatval($item['price']);
            $totalPrice = $price * $quantity;

            // تحقق من وجود المنتج والمخزون
            $stockQuery = "SELECT stock FROM cat_products WHERE id = $productId";
            $stockResult = $conn->query($stockQuery);
            if ($stockResult->num_rows > 0) {
                $row = $stockResult->fetch_assoc();
                if ($row['stock'] >= $quantity) {
                    // تقليل المخزون
                    $updateStockQuery = "UPDATE cat_products SET stock = stock - $quantity WHERE id = $productId";
                    $conn->query($updateStockQuery);

                    // إضافة الطلب إلى جدول orders
                    $orderQuery = "INSERT INTO orders (user_name, product_name, quantity, total_price, order_date) 
                                   VALUES ('$userName', '$name', $quantity, $totalPrice, NOW())";
                    $conn->query($orderQuery);
                } else {
                    echo "Not enough stock for $name!";
                    exit;
                }
            } else {
                echo "Product not found!";
                exit;
            }
        }
        echo "Order placed successfully!";
    } else {
        echo "Cart is empty!";
    }
    exit;
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles/store.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Cat Store</title>
</head>

<body>
<header>
<nav>
        <a href="move.html">Store</a>
        <a href="index.html">Clinic</a>
    </nav>
        
    </header>

    <button class="cart-toggle" onclick="toggleCart()">
        <i class="fa fa-shopping-cart"></i>
    </button>

    <div class="row" id="items">
        <?php foreach ($products as $product): ?>
            <div class="column">
                <p><strong><?php echo $product['name']; ?></strong></p>
                <p><?php echo $product['price']; ?> SAR</p>
                <p>Stock: <span id="stock-<?php echo $product['id']; ?>"><?php echo $product['stock']; ?></span></p>
                <button onclick="addToCart(<?php echo $product['id']; ?>, '<?php echo $product['name']; ?>', <?php echo $product['price']; ?>)">
                    Add To Cart
                </button>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="cart" id="cart">
        <button class="close-btn" onclick="toggleCart()">X</button>
        <h3>Your Cart</h3>
        <div id="cart-items"></div>
        <p><strong>Total:</strong> <span id="cart-total">0</span> SAR</p>
        <button class="btn-buy" onclick="checkout()">Buy Now</button>
    </div>

    <script>
        const cart = [];

        function toggleCart() {
            const cart = document.getElementById("cart");
            cart.classList.toggle("open");
        }

        function addToCart(id, name, price) {
            const cartItem = cart.find(item => item.id === id);
            if (cartItem) {
                cartItem.quantity++;
            } else {
                cart.push({ id, name, price, quantity: 1 });
            }
            updateCart();
        }

        function updateCart() {
            const cartItemsDiv = document.getElementById('cart-items');
            const cartTotal = document.getElementById('cart-total');
            cartItemsDiv.innerHTML = '';
            let total = 0;

            cart.forEach(item => {
                const itemDiv = document.createElement('div');
                itemDiv.textContent = `${item.name} x${item.quantity} - ${item.price * item.quantity} SAR`;
                cartItemsDiv.appendChild(itemDiv);
                total += item.price * item.quantity;
            });

            cartTotal.textContent = total;
        }

        function checkout() {
            if (cart.length === 0) {
                alert("Your cart is empty!");
                return;
            }

            fetch('CatStore.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `cartData=${encodeURIComponent(JSON.stringify(cart))}`
            })
                .then(response => response.text())
                .then(data => {
                    alert(data);
                    if (data.includes("success")) location.reload();
                })
                .catch(error => console.error('Error:', error));
        }
    </script>
</body>

</html>