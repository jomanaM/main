<?php
include 'db.php'; // الاتصال بقاعدة البيانات

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // جمع بيانات الموعد من المستخدم
    $appointment = [
        'name' => $_POST['name'],
        'phone' => $_POST['phone'],
        'email' => $_POST['email'],
        'date' => $_POST['date'],
        'time' => $_POST['time'],
        'service' => $_POST['service'],
        'confirmation' => $_POST['confirmation'],
    ];

    // تحويل البيانات إلى JSON وحفظها في ملف
    $json_data = json_encode($appointment, JSON_PRETTY_PRINT);
    file_put_contents('appointment.json', $json_data);

    // محاولة إرسال البيانات إلى قاعدة البيانات
    try {
        $sql = "INSERT INTO appointments (name, phone, email, date, time, service, confirmation) 
                VALUES ('{$appointment['name']}', '{$appointment['phone']}', '{$appointment['email']}', 
                        '{$appointment['date']}', '{$appointment['time']}', 
                        '{$appointment['service']}', '{$appointment['confirmation']}')";

        if ($conn->query($sql) === TRUE) {
            echo "<p style='color: green; text-align: center;'>Appointment saved to database successfully!</p>";
        } else {
            throw new Exception("Error: " . $sql . "<br>" . $conn->error);
        }
    } catch (Exception $e) {
        echo "<p style='color: red; text-align: center;'>Failed to save appointment to database. Data saved in JSON.</p>";
        error_log($e->getMessage(), 3, "error.log"); // تسجيل الخطأ في ملف
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 100%;
            max-width: 600px;
            margin: 50px auto;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            padding: 30px;
        }

        h1 {
            text-align: center;
            color: #584C3C;
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 8px;
            color: #333;
        }

        input[type="text"],
        input[type="email"],
        input[type="date"],
        input[type="time"],
        button {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }

        input[type="radio"] {
            margin-right: 10px;
        }

        button {
            background-color: #584C3C;
            color: white;
            font-size: 16px;
            font-weight: bold;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background-color: #F87A17;
        }

        .service-field {
            background-color: #f0f0f0;
            cursor: not-allowed;
        }

        .form-header img {
            display: block;
            margin: 0 auto 20px;
            max-width: 120px;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="form-header">
            <img src="img/logo.jpeg" alt="Logo">///
            <h1>Book Appointment</h1>
        </div>
        <form action="appointment.php" method="POST">
            <label for="name">Full Name</label>
            <input type="text" name="name" id="name" placeholder="Enter your full name" required>

            <label for="phone">Phone Number</label>
            <input type="text" name="phone" id="phone" placeholder="Enter your phone number" required>

            <label for="email">Email Address</label>
            <input type="email" name="email" id="email" placeholder="Enter your email" required>

            <label for="service">Selected Service</label>
            <input type="text" name="service" id="service" value="<?php echo isset($_GET['service']) ? htmlspecialchars($_GET['service']) : 'Not selected'; ?>" class="service-field" readonly>

            <label for="date">Date</label>
            <input type="date" name="date" id="date" required>

            <label for="time">Time</label>
            <input type="time" name="time" id="time" required>

            <div>
                <label>Confirmation requested by:</label>
                <label>
                    <input type="radio" name="confirmation" value="email" checked> Email
                </label>
                <label>
                    <input type="radio" name="confirmation" value="phone"> Phone call
                </label>
            </div>

            <button type="submit" onclick="showAlert()">Book Appointment</button>
        </form>
    </div>

    <script>
        function showAlert() {
            alert("Your reservation has been sent and we \n will send confirmation as soon as possible ✓");
        }
    </script>
</body>

</html>
