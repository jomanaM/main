<?php
// قراءة محتوى cart.json
$cartFile = 'cart.json';
$cartData = json_decode(file_get_contents($cartFile), true);

// التحقق من نوع الطلب (GET أو POST)
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // إعادة السلة كـ JSON
    echo json_encode($cartData);
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // جلب البيانات المرسلة
    $product = json_decode(file_get_contents('php://input'), true);
    
    // إضافة المنتج إلى السلة
    $cartData[] = $product;

    // حفظ البيانات في cart.json
    file_put_contents($cartFile, json_encode($cartData, JSON_PRETTY_PRINT));

    echo json_encode(['message' => 'Product added to cart']);
}
?>
