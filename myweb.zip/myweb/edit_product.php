<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // إضافة منتج جديد
    if (isset($_POST['add_product'])) {
        $name = $_POST['name'];
        $price = $_POST['price'];
        $stock = $_POST['stock'];

        $sql = "INSERT INTO products (name, price, stock) VALUES ('$name', $price, $stock)";
        if ($conn->query($sql) === TRUE) {
            $message = "Product added successfully!";
        } else {
            $message = "Error: " . $conn->error;
        }
    }

    // تحديث منتج
    if (isset($_POST['update_product'])) {
        $id = intval($_POST['id']);
        $name = $_POST['name'];
        $price = $_POST['price'];
        $stock = $_POST['stock'];

        $sql = "UPDATE products SET name = '$name', price = $price, stock = $stock WHERE id = $id";
        if ($conn->query($sql) === TRUE) {
            $message = "Product updated successfully!";
        } else {
            $message = "Error: " . $conn->error;
        }
    }

    // حذف منتج
    if (isset($_POST['delete_product'])) {
        $id = intval($_POST['id']);

        $sql = "DELETE FROM products WHERE id = $id";
        if ($conn->query($sql) === TRUE) {
            $message = "Product deleted successfully!";
        } else {
            $message = "Error: " . $conn->error;
        }
    }
}

// جلب المنتجات من قاعدة البيانات
$sql = "SELECT * FROM products";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Manage Products</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background-color: #fff;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }

        table th {
            background-color: #584C3C;
            color: white;
        }

        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        table tr:hover {
            background-color: #f1f1f1;
        }

        form {
            margin-bottom: 20px;
        }

        input[type="text"],
        input[type="number"] {
            padding: 5px;
            margin: 5px 0;
            width: 100%;
            box-sizing: border-box;
        }

        button {
            background-color: #584C3C;
            color: white;
            border: none;
            padding: 10px 15px;
            cursor: pointer;
            border-radius: 5px;
        }

        button:hover {
            background-color: #f87a17;
        }

        p {
            color: green;
        }
    </style>
</head>
<body>
    <h1>Manage Products</h1>

    <?php if (isset($message)): ?>
        <p><?php echo $message; ?></p>
    <?php endif; ?>

    <!-- إضافة منتج جديد -->
    <form method="POST">
        <h2>Add New Product</h2>
        <label for="name">Product Name:</label>
        <input type="text" name="name" id="name" required>

        <label for="price">Price:</label>
        <input type="number" name="price" id="price" required>

        <label for="stock">Stock:</label>
        <input type="number" name="stock" id="stock" required>

        <button type="submit" name="add_product">Add Product</button>
    </form>

    <!-- عرض المنتجات -->
    <h2>Product List</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Price</th>
            <th>Stock</th>
            <th>Actions</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['price']; ?></td>
                <td><?php echo $row['stock']; ?></td>
                <td>
                    <!-- نموذج تعديل -->
                    <form method="POST" style="display: inline;">
                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                        <input type="text" name="name" value="<?php echo $row['name']; ?>" required>
                        <input type="number" name="price" value="<?php echo $row['price']; ?>" required>
                        <input type="number" name="stock" value="<?php echo $row['stock']; ?>" required>
                        <button type="submit" name="update_product">Update</button>
                    </form>

                    <!-- نموذج حذف -->
                    <form method="POST" style="display: inline;">
                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                        <button type="submit" name="delete_product">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
