// جلب السلة من localStorage أو إنشاء سلة جديدة إذا ما كانت موجودة
let cart = JSON.parse(localStorage.getItem('cart')) || [];

// إضافة منتج جديد للسلة
function addToCart(product) {
    cart.push(product);
    localStorage.setItem('cart', JSON.stringify(cart));
    alert(`${product.name} has been added to the cart!`);
}

// تحميل السلة عند فتح الصفحة
function loadCart() {
    cart = JSON.parse(localStorage.getItem('cart')) || [];
    console.log("Cart loaded:", cart);
}

// حذف عنصر من السلة
function removeFromCart(productName) {
    cart = cart.filter(product => product.name !== productName);
    localStorage.setItem('cart', JSON.stringify(cart));
    alert(`${productName} has been removed from the cart.`);
}

// عرض السلة في الكونسول
function showCart() {
    console.log("Your Cart:", cart);
}
