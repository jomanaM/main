<?php
session_start(); // بدء الجلسة
include 'db.php';

try {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $email = filter_var($_POST['myEmail'], FILTER_VALIDATE_EMAIL);
        $password = trim($_POST['myPassword']);

        if (!$email) {
            throw new Exception("Invalid email format.");
        }

        if (strlen($password) < 6) {
            throw new Exception("Password must be at least 6 characters long.");
        }

        // تحديد الزمن المسموح للمحاولات (آخر 15 دقيقة)
        $time_limit = date("Y-m-d H:i:s", strtotime("-15 minutes"));

        // حساب عدد المحاولات الفاشلة
        $sql = "SELECT COUNT(*) AS failed_attempts FROM login_attempts WHERE email='$email' AND attempt_time > '$time_limit'";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        $failed_attempts = $row['failed_attempts'];

        // تحديد الحد الأقصى للمحاولات
        $max_attempts = 3;

        if ($failed_attempts >= $max_attempts) {
            $error_message = "You have exceeded the maximum number of login attempts. Please try again after 15 minutes.";
        } else {
            // محاولة تسجيل الدخول
            $sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";
            $result = $conn->query($sql);

            if (!$result) {
                throw new Exception("Database query failed.");
            }

            if ($result->num_rows > 0) {
                // تسجيل الدخول الناجح
                $user = $result->fetch_assoc();
                $user_id = $user['id'];
                $user_name = $user['name']; // اسم المستخدم من قاعدة البيانات
                $user_role = $user['role']; // دور المستخدم

                // تخزين بيانات المستخدم في الجلسة
                $_SESSION['user_name'] = $user_name;
                $_SESSION['user_id'] = $user_id;
                $_SESSION['user_role'] = $user_role;

                $timestamp = date("Y-m-d H:i:s");
                $log = "User ID: $user_id | Email: $email | Role: $user_role | Logged in at: $timestamp\n";
                file_put_contents("user_activity.log", $log, FILE_APPEND);

                // إعادة التوجيه بناءً على الدور
                if ($user_role === 'admin') {
                    header("Location: home_admin.html");
                } else {
                    header("Location: index.html");
                }
                exit;
            } else {
                // تسجيل المحاولة الفاشلة
                $sql = "INSERT INTO login_attempts (email, attempt_time) VALUES ('$email', NOW())";
                $conn->query($sql);

                $error_message = "Invalid email or password.";
            }
        }
    }
} catch (Exception $e) {
    $error_message = "An error occurred: " . $e->getMessage();
    error_log(date("[Y-m-d H:i:s]") . " " . $e->getMessage() . "\n", 3, "error.log");
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <title>- pets - Log In </title>
    <style>
        body {
            font-family: 'Times New Roman', Times, serif;
            background-color: #e7dec7;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        img {
            margin-bottom: 10px; 
            align-self: flex-start;
        }

        header {
            text-align: center;
            margin-bottom: 5px;
            font-size: 24px;
            color: #6f4c3e;
        }

        main {
            background-color: rgb(249, 240, 223);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            width: 400px;
            max-width: 100%;
            margin-top: 10px;
        }

        label {
            font-weight: bold;
            margin-top: 5px;
            display: block;
            color: #6f4c3e;
        }

        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 8px;
            margin: 5px 0 10px 0;
            border: 2px solid #8b4513;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            color: #6f4c3e;
        }

        input[type="submit"] {
            padding: 10px 15px;
            background: linear-gradient(135deg, #d2b48c, #c1a57a);
            color: #6f4c3e;
            border: 2px solid #6f4c3e;
            border-radius: 10px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            transition: background-color 0.3s, border-color 0.3s, box-shadow 0.3s;
            width: 100%;
        }

        input[type="submit"]:hover {
            background-color: #c1a57a;
            border-color: #524b3f;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
        }

        nav {
            margin: 20px 0;
        }

        nav a {
            color: #d2b48c;
            text-decoration: none;
        }

        nav a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <img src="logo.png" alt="pets logo" width="221" height="173">

    <header>
        <h1>Log In</h1>
    </header>

    <main>
        <form action="login.php" method="POST">
            <label for="myEmail">EMAIL:</label>
            <input type="email" name="myEmail" required="required">

            <label for="myPassword">PASSWORD:</label>
            <input type="password" name="myPassword" required="required">

            <?php if (!empty($error_message)): ?>
                <p style="color: red;"><?php echo $error_message; ?></p>
            <?php endif; ?>

            <nav>
                <a href="signup.php">New User? Sign Up</a>
            </nav>

            <input type="submit" value="Log In">
        </form>
    </main>
</body>

</html>
