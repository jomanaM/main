<?php
include 'db.php';

try {
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['cartData'])) {
        $cartData = json_decode($_POST['cartData'], true);

        if (empty($cartData)) {
            throw new Exception("Cart is empty!");
        }

        $user_name = isset($_SESSION['user_name']) ? $_SESSION['user_name'] : 'Guest';
        $product_names = [];
        $total_price = 0;

        foreach ($cartData as $item) {
            $product_names[] = $item['name'];
            $total_price += $item['price'] * $item['quantity'];
        }

        $product_names_str = implode(", ", $product_names);

        $sql = "INSERT INTO orders (user_name, product_name, total_price, order_date) 
                VALUES ('$user_name', '$product_names_str', $total_price, NOW())";

        if ($conn->query($sql) === TRUE) {
            echo "Order placed successfully!";
        } else {
            throw new Exception("Error: " . $conn->error);
        }
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>
