<?php
// قراءة بيانات المواعيد من ملف JSON
$appointments = json_decode(file_get_contents('appointments.json'), true);

// فرضية: البريد الإلكتروني للمستخدم الحالي
$currentUserEmail = 'admin@example.com'; // استبدل هذا بالقيمة الفعلية للمستخدم، مثل session أو متغير آخر

// فلترة المواعيد بناءً على نوع المستخدم
if ($currentUserEmail === 'admin@example.com') {
    // إذا كان الإداري، عرض جميع المواعيد
    $filteredAppointments = $appointments;
} else {
    // عرض مواعيد المستخدم فقط
    $filteredAppointments = array_filter($appointments, function($appointment) use ($currentUserEmail) {
        return isset($appointment['email']) && $appointment['email'] === $currentUserEmail;
    });
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment Reports - Clinic Management System</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f3f4f6;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }
        h1, h2 {
            color: #6f4c3e; /* لون بني */
        }
        button {
            background-color: #6f4c3e; /* لون بني */
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
        }
        button:hover {
            background-color: #5b3e31; /* لون أغمق عند التمرير */
        }
        a {
            text-decoration: none;
            color: #6f4c3e; /* لون بني */
            display: inline-block;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Appointment Reports</h1>

        <h2>Appointment Details</h2>
        <ul>
            <?php if (count($filteredAppointments) > 0): ?>
                <?php foreach ($filteredAppointments as $appointment): ?>
                    <li>
                        Name: <?php echo htmlspecialchars($appointment['name']); ?> -
                        Phone: <?php echo htmlspecialchars($appointment['phone']); ?> -
                        Email: <?php echo htmlspecialchars($appointment['email']); ?> -
                        Service: <?php echo htmlspecialchars($appointment['service']); ?> -
                        Date: <?php echo htmlspecialchars($appointment['date']); ?> -
                        Time: <?php echo htmlspecialchars($appointment['time']); ?> -
                        Confirmation: <?php echo htmlspecialchars($appointment['confirmation']); ?> -
                        <form method="POST" action="cancel_appointment.php" style="display:inline;">
                            <input type="hidden" name="email" value="<?php echo htmlspecialchars($appointment['email']); ?>">
                            <input type="hidden" name="date" value="<?php echo htmlspecialchars($appointment['date']); ?>">
                            <input type="hidden" name="time" value="<?php echo htmlspecialchars($appointment['time']); ?>">
                            <button type="submit">Cancel Appointment</button>
                        </form>
                    </li>
                <?php endforeach; ?>
            <?php else: ?>
                <li>No appointments found for this user.</li>
            <?php endif; ?>
        </ul>
        <a href="<?php echo ($currentUserEmail === 'admin@example.com') ? 'home_admin.html' : 'index.html'; ?>">Back to Home</a>

    </div>
</body>
</html>