<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['MyName'];
    $email = $_POST['myEmail'];
    $password = $_POST['myPassword'];
    $birth_date = $_POST['myDate'];

    // التحقق إذا كان البريد الإلكتروني موجودًا
    $check_email = "SELECT * FROM users WHERE email='$email'";
    $result = $conn->query($check_email);

    if ($result->num_rows > 0) {
        // إذا كان البريد موجود، عرض رسالة خطأ
        $error_message = "This email is already registered. Please use a different email.";
    } else {
        // إذا لم يكن البريد موجود، إضافة المستخدم
        $sql = "INSERT INTO users (name, email, password, birth_date) VALUES ('$name', '$email', '$password', '$birth_date')";

        if ($conn->query($sql) === TRUE) {
            $success_message = "New account created successfully!";
            header("Refresh: 2; URL=login.php");
            exit;
        } else {
            $error_message = "Error: " . $conn->error;
        }
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>- pets - Sign Up </title>
    <style>
        body {
            font-family: 'Times New Roman', Times, serif;
            background-color: #e7dec7;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        img {
            margin-bottom: 10px; /* تقليل المسافة تحت الشعار */
            align-self: flex-start;
        }

        header {
            text-align: center;
            margin-bottom: 5px; /* تقليل المسافة تحت الهيدر */
            font-size: 24px;
            color: #6f4c3e;
        }

        nav {
            margin-bottom: 10px;
        }

        nav a {
            color: #d2b48c; /* لون النص البني الفاتح */
            text-decoration: none; /* إزالة التسطير */
        }

        nav a:hover {
            text-decoration: underline; /* إضافة التسطير عند التحويم */
        }

        main {
            background-color: rgb(249, 240, 223);
            padding: 30px; /* زيادة الحشوة لجعل الخلفية أكبر */
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            width: 400px;
            max-width: 100%;
            margin-top: 10px; /* تقليل المسافة فوق النموذج */
        }

        label {
            font-weight: bold;
            margin-top: 5px;
            display: block;
            color: #6f4c3e; /* لون نص التسميات */
        }

        input[type="text"],
        input[type="email"],
        input[type="password"],
        input[type="date"] {
            width: 100%;
            padding: 8px;
            margin: 5px 0 10px 0;
            border: 2px solid #8b4513;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            color: #6f4c3e; /* لون نص الحقول */
        }

        input[type="submit"] {
            padding: 10px 15px;
            background: linear-gradient(135deg, #d2b48c, #c1a57a);
            color: #6f4c3e;
            border: 2px solid #6f4c3e;
            border-radius: 10px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            transition: background-color 0.3s, border-color 0.3s, box-shadow 0.3s;
            width: 100%;
        }

        input[type="submit"]:hover {
            background-color: #c1a57a;
            border-color: #524b3f;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
        }
    </style>
</head>

<body>
    <img src="logo.png" alt="pets logo" width="221" height="173">

    <header>
        <h1>Create New Account</h1>
    </header>

    <nav>
        <a href="login.php">Already Registered? Login</a>
        <br>
    </nav>

    <main>
        <form action="signup.php" method="POST">
            <label for="MyName">Name:</label>
            <input type="text" name="MyName" required="required">

            <label for="myEmail">EMAIL:</label>
            <input type="email" name="myEmail" required="required">

            <label for="myPassword">PASSWORD:</label>
            <input type="password" name="myPassword" required="required">

            <label for="myDate">BIRTHDAY:</label>
            <input type="date" name="myDate" required="required">

            <?php if (!empty($error_message)): ?>
                <p style="color: red;"><?php echo $error_message; ?></p>
            <?php endif; ?>

            <?php if (!empty($success_message)): ?>
                <p style="color: green;"><?php echo $success_message; ?></p>
            <?php endif; ?>

            <input type="submit" value="Sign Up">
        </form>
    </main>
</body>

</html>
